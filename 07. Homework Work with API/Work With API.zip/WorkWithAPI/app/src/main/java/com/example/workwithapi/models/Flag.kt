package com.example.workwithapi.models

data class Flag(
    var svg: String,
    var png: String
)